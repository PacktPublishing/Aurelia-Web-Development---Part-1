export class App {
  constructor() {
    this.message = 'Hello World!';
  }
}

export default {
  debug: true,
  testing: true
};

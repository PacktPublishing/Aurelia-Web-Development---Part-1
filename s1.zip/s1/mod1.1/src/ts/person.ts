class Person {
    private firstName: string;
    private lastName: string;
    constructor(firstName: string = "fn", lastName: string = "ln") {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    toString() : string {
        return `${this.lastName}, ${this.firstName}`;
    }
}

let p = new Person("Raja", "Mani");
console.log("TypeScript: ", p.toString());
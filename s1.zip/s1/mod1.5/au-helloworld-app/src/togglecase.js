export class ToggleCaseValueConverter {
  toView(value, n) {
    return (n <= value.length ? value.substring(0, n).toLowerCase() + value.substring(n) : value.toLowerCase());
  }
  fromView(value, n) {
    return (n <= value.length ? value.substring(0, n).toUpperCase() + value.substring(n) : value.toUpperCase());
  }
}

import {computedFrom} from "aurelia-framework";
export class Greeter {
  constructor(firstName = "fn", lastName = "ln") {
    this.firstName = firstName;
    this.lastName = lastName;
    (setTimeout(() => this.update(), 2000));
    this.styleString = "text-decoration: overline;";
    this.styleObject = {
      "text-decoration": "underline"
    };
  }
  get greeting() {
    let currentTime = new Date().getHours();
    return "Good " +  (currentTime < 12 ? "Morning" : currentTime < 18 ? "Afternoon" : "Evening");
  }

  @computedFrom("firstName", "lastName")
  get fullName() {
    console.log(`${this.lastName}, ${this.firstName}`);
    return `${this.lastName}, ${this.firstName}`;
  }

  update() {
    this.firstName = "Raja";
    this.lastName = "Mani";
    console.log(this.lastName, this.firstName);
  }
}
